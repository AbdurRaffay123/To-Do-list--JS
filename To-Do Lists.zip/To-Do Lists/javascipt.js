const inputBox = document.getElementById("inputBox");
const lists = document.querySelector(".lists");
const check = document.querySelector(".checked");

const addtask=()=>{
  //Alert will show if we enter nothing int search-box
  if (inputBox.value === "" || inputBox.value === " "){
    alert(`You haven't Entered any Text`);
}else{
    var li = document.createElement("li");
    li.innerHTML = inputBox.value;
    lists.appendChild(li);
    let icon = document.createElement("span");
    icon.innerHTML = "\u00d7"; //'Cross' for Deleting tasks
    li.appendChild(icon);
    saveData();
  }
  inputBox.value = "";
  //This Function will be called every time we perform anything with our task
  saveData();
}

lists.addEventListener("click", function(e){
    if (e.target.tagName === "SPAN"){
     e.target.parentElement.remove();
  //This Function will be called every time we perform anything with our task
      saveData();
    }else if (e.target.tagName === "LI") {
      e.target.classList.toggle("checked");
  //This Function will be called every time we perform anything with our task
      saveData();
    }
},false);

//Saving every tasks on local Storage of Chrome:
const saveData = () => {
  localStorage.setItem("data", lists.innerHTML);
};

// Displaying the tasks that we have written in the Chrome:
const showTasks = () => {
  lists.innerHTML = localStorage.getItem("data");
};

// Calling function of Diplaying Data
    showTasks();

    // ~~~~EXTRA'SSS:-


//For adding "enter" but not working.
// inputBox.addEventListener("keypress", function (event) {
//     if (event.key === "Enter") {
//         event.preventDefault();
//         addTask();
//     }
// });

//For deleting tasks:-

// icon.onclick=()=>{
//         li.remove();
//     }
// }
